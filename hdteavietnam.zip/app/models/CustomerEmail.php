<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class CustomerEmail extends Model
{
    protected $table = "customer_email";
}
